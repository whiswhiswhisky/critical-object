console.log("server is starting!");
//Set up variables -------------------------------------------
var profileId = ""
var content = ""
var code ='';
var endpoint1 = "/report/";
var endpoint2 = "/marker/?accession_id=NC_000011.9";

//Set up server -------------------------------------------
var path = require('path');
var fs = require('fs');
var express = require('express');
var https = require('https');
var bodyParser = require('body-parser')
var request = require('request');
var jsdom = require('jsdom');
const { JSDOM } = jsdom;
const { window } = new JSDOM();
const { document } = (new JSDOM('')).window;
global.document = document;
var $ = jQuery = require('jquery')(window);
var router = express.Router();
var app = express();

//Start server
var server = app.listen(5000,listening);
function listening(){
    console.log("i am listening!");
}

var jsonParser = bodyParser.json()

//Establish paths
app.use(express.static(__dirname + '/public'));
app.use("/images",  express.static(__dirname + '/public/images'));

//Main code: Get data from user -------------------------------------------
app.get('/receive_code', function (req, res) {
    code = req.originalUrl.substring(20);
    var html = '';

    // STEP 1: Authorization -- get token ----------------
    request.post({
        url: 'https://api.23andme.com/token/',
        form: {
            client_id: 'ad5e80182caf937c0858c0ad8584b3f2',
            client_secret: '146aca1f1458f0f933eab1934468e24d',
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: "http://localhost:5000/receive_code/",
            scope: "basic report:all genomes"
        },
        json: true }, 

            //STEP 2: Get User's Profile ID  ----------------
            function(e, r, body) {
            if (!e && r.statusCode == 200) {
                var headers = {Authorization: 'Bearer ' + body.access_token};

                request.get({ url:'https://api.23andme.com/3/account/', headers: headers, json: true}, function (e, r, b) {
                    profileId = b.data[0].profiles[0].id;

                    // STEP 3: Get User's Report  ----------------
                    if (profileId.length > 0){
                        request.get({ url:'https://api.23andme.com/3/profile/'+profileId+endpoint2, headers: headers, json: true}, function (e, r, b) {
                        console.log(b);
                        content = b;

                        res.redirect("http://localhost:5000/ending/")
                        console.log("DIRECTED!!")

                        });
                    } 
                                       
                });

            } else {
                console.log('fail');
                res.send(body);
            }
        });

    // res.send(html)
  })

//Store fetched data as json on result page -------------------------------------------
app.get('/result',updateContent)
function updateContent(request,response){
    response.send(content);
}

app.get('/ending', function(req, res) {
    res.sendFile(path.join(__dirname, "public", 'ending.html'));
});